n = int(input())






for item in range(1, n+1):
    print(item, end="")